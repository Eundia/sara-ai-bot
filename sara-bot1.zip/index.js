const restify = require('restify');
const { BotFrameworkAdapter } = require('botbuilder');

const server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, () => {
    console.log(`\nBot is listening on ${server.url}`);
});

const adapter = new BotFrameworkAdapter({
    appId: process.env.MicrosoftAppId,
    appPassword: process.env.MicrosoftAppPassword
});

adapter.onTurnError = async (context, error) => {
    console.error(`\n [onTurnError]: ${ error }`);
    await context.sendActivity('Oops. Something went wrong!');
};

server.post('/api/messages', (req, res) => {
    adapter.processActivity(req, res, async (context) => {
        await context.sendActivity(`You said: ${ context.activity.text }`);
    });
});
